package com.company;

import java.util.Scanner;

        public class Main {

            public static void main(String[] args) {
                // write your code here
                int pen = 20;
                int hero = 80;
                int cost;
                String name;

                System.out.println("what is your sweet name :");
                Scanner input = new Scanner(System.in);
                name= input.next();
                System.out.println("welcom  " +name);
                System.out.println(" how much money in there:");
                cost = input.nextInt();



                System.out.println("how much money in there:" +cost);

                if (cost > hero){
                    System.out.println("your buy it heropen");
                }

                else if(cost > pen){
                    System.out.println("your buy it pen");
                }

                else{
                    System.out.println("sorry");
                }


            }
        }

